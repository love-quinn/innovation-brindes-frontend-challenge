(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2a872_de3b4629._.js",
  "static/chunks/innovation-brindes-frontend-challenge_44713bb5._.js"
],
    source: "dynamic"
});
