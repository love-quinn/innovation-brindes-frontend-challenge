(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/innovation-brindes-frontend-challenge/store/productModalStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProductModalStore",
    ()=>useProductModalStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const useProductModalStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        isOpen: false,
        hasEverOpened: false,
        product: null,
        returnFocusElement: null,
        open: (product, triggerElement)=>set({
                isOpen: true,
                hasEverOpened: true,
                product,
                returnFocusElement: triggerElement ?? null
            }),
        close: ()=>{
            const el = get().returnFocusElement;
            set({
                isOpen: false,
                product: null,
                returnFocusElement: null
            });
            if (typeof requestAnimationFrame !== "undefined" && el?.focus) {
                requestAnimationFrame(()=>el.focus());
            }
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/services/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "api",
    ()=>api
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/lib/auth-constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/authStore.ts [app-client] (ecmascript)");
;
;
;
const API_BASE_URL = "https://apihomolog.innovationbrindes.com.br/api/innova-dinamica";
const api = __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});
/**
 * REQUEST INTERCEPTOR
 * Adiciona automaticamente o token em todas as requisições
 */ api.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]);
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
});
/**
 * RESPONSE INTERCEPTOR
 * 401 → logout (Zustand + localStorage + cookie) e redirect /login
 */ api.interceptors.response.use((response)=>response, (error)=>{
    if (error.response?.status === 401 && ("TURBOPACK compile-time value", "object") !== "undefined") {
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"].getState().logout();
        window.location.href = "/login";
    }
    return Promise.reject(error);
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/services/products.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getProductsList",
    ()=>getProductsList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/services/api.ts [app-client] (ecmascript)");
;
async function getProductsList() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].get("/produtos/listar");
    if (Array.isArray(data)) return data;
    if (data && typeof data === "object" && "data" in data && Array.isArray(data.data)) {
        return data.data;
    }
    return [];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/hooks/useProducts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useProducts",
    ()=>useProducts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useInfiniteQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$products$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/services/products.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const PAGE_SIZE = 8;
const DEBOUNCE_MS = 400;
function filterProducts(products, search) {
    if (!search.trim()) return products;
    const lower = search.trim().toLowerCase();
    return products.filter((p)=>p.nome.toLowerCase().includes(lower) || p.codigo.toLowerCase().includes(lower) || p.referencia && p.referencia.toLowerCase().includes(lower));
}
function sortProducts(products, sortBy, sortOrder) {
    const sorted = [
        ...products
    ];
    if (sortBy === "nome") {
        sorted.sort((a, b)=>{
            const cmp = a.nome.localeCompare(b.nome, "pt-BR");
            return sortOrder === "asc" ? cmp : -cmp;
        });
    } else {
        sorted.sort((a, b)=>{
            const pa = parseFloat(a.preco) || 0;
            const pb = parseFloat(b.preco) || 0;
            return sortOrder === "asc" ? pa - pb : pb - pa;
        });
    }
    return sorted;
}
function useProducts() {
    _s();
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [debouncedSearch, setDebouncedSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [sortBy, setSortBy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("nome");
    const [sortOrder, setSortOrder] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("asc");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useProducts.useEffect": ()=>{
            const t = setTimeout({
                "useProducts.useEffect.t": ()=>setDebouncedSearch(search)
            }["useProducts.useEffect.t"], DEBOUNCE_MS);
            return ({
                "useProducts.useEffect": ()=>clearTimeout(t)
            })["useProducts.useEffect"];
        }
    }["useProducts.useEffect"], [
        search
    ]);
    const cacheRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useInfiniteQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInfiniteQuery"])({
        queryKey: [
            "products",
            debouncedSearch,
            sortBy,
            sortOrder
        ],
        queryFn: {
            "useProducts.useInfiniteQuery[query]": async ({ pageParam = 0 })=>{
                const key = `${debouncedSearch}|${sortBy}|${sortOrder}`;
                let fullList;
                if (cacheRef.current?.key === key) {
                    fullList = cacheRef.current.list;
                } else {
                    const all = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$products$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProductsList"])();
                    fullList = sortProducts(filterProducts(all, debouncedSearch), sortBy, sortOrder);
                    cacheRef.current = {
                        key,
                        list: fullList
                    };
                }
                const start = pageParam * PAGE_SIZE;
                const items = fullList.slice(start, start + PAGE_SIZE);
                const nextPage = start + PAGE_SIZE < fullList.length ? pageParam + 1 : undefined;
                return {
                    items,
                    nextPage
                };
            }
        }["useProducts.useInfiniteQuery[query]"],
        getNextPageParam: {
            "useProducts.useInfiniteQuery[query]": (lastPage)=>lastPage.nextPage
        }["useProducts.useInfiniteQuery[query]"],
        initialPageParam: 0,
        staleTime: 2 * 60 * 1000,
        retry: 1
    });
    const products = query.data?.pages.flatMap((p)=>p.items) ?? [];
    const hasNextPage = query.hasNextPage;
    const isFetchingNextPage = query.isFetchingNextPage;
    const isEmpty = !query.isLoading && !query.isFetching && debouncedSearch === search && products.length === 0;
    const toggleSort = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useProducts.useCallback[toggleSort]": (by)=>{
            setSortBy({
                "useProducts.useCallback[toggleSort]": (prevBy)=>{
                    if (prevBy !== by) {
                        setSortOrder("asc");
                        return by;
                    }
                    setSortOrder({
                        "useProducts.useCallback[toggleSort]": (o)=>o === "asc" ? "desc" : "asc"
                    }["useProducts.useCallback[toggleSort]"]);
                    return by;
                }
            }["useProducts.useCallback[toggleSort]"]);
        }
    }["useProducts.useCallback[toggleSort]"], []);
    return {
        products,
        search,
        setSearch,
        debouncedSearch,
        sortBy,
        sortOrder,
        setSortBy,
        setSortOrder,
        toggleSort,
        fetchNextPage: query.fetchNextPage,
        hasNextPage: !!hasNextPage,
        isFetchingNextPage,
        isLoading: query.isLoading,
        isError: query.isError,
        error: query.error,
        refetch: query.refetch,
        isEmpty
    };
}
_s(useProducts, "If6vZaM8ipjFbpo7RgfGyU7UmhI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useInfiniteQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInfiniteQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/store/favoritesStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFavoritesStore",
    ()=>useFavoritesStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const STORAGE_KEY = "favorites";
function readFromStorage() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw == null) return [];
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) && parsed.every((x)=>typeof x === "string") ? parsed : [];
    } catch  {
        return [];
    }
}
function writeToStorage(ids) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
    } catch  {
    // ignore
    }
}
const useFavoritesStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        favoriteIds: [],
        isFavorite: (id)=>get().favoriteIds.includes(id),
        toggleFavorite: (id)=>{
            set((state)=>{
                const next = state.favoriteIds.includes(id) ? state.favoriteIds.filter((x)=>x !== id) : [
                    ...state.favoriteIds,
                    id
                ];
                writeToStorage(next);
                return {
                    favoriteIds: next
                };
            });
        },
        setFavorites: (ids)=>{
            const next = [
                ...ids
            ];
            writeToStorage(next);
            set({
                favoriteIds: next
            });
        },
        clearFavorites: ()=>{
            writeToStorage([]);
            set({
                favoriteIds: []
            });
        },
        hydrate: ()=>{
            const ids = readFromStorage();
            set({
                favoriteIds: ids
            });
        }
    })); /*
  Manual test checklist (ETAPA 12):
  1. Favorite 2 items -> reload page -> they still show as favorited (filled heart).
  2. Toggle "Mostrar apenas favoritos" on -> only favorited products appear in the grid.
  3. Unfavorite one item from the filtered view -> it disappears from the list immediately.
  4. With filter on and zero favorites -> empty state shows with message and button to disable filter.
*/ 
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductCard",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$productModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/productModalStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/favoritesStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function formatPrice(preco) {
    const n = parseFloat(preco);
    if (Number.isNaN(n)) return "";
    return n.toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}
const PLACEHOLDER_COLORS = [
    "#3b82f6",
    "#22c55e",
    "#94a3b8",
    "#ef4444",
    "#f97316",
    "#eab308",
    "#a16207"
];
const FALLBACK_IMAGE = "/box.png";
function ProductCard({ product, isAboveFold = false, isLcpCandidate = false }) {
    _s();
    const [imageError, setImageError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$productModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductModalStore"])({
        "ProductCard.useProductModalStore[openModal]": (s)=>s.open
    }["ProductCard.useProductModalStore[openModal]"]);
    const isFavorite = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"])({
        "ProductCard.useFavoritesStore[isFavorite]": (s)=>s.isFavorite(product.codigo)
    }["ProductCard.useFavoritesStore[isFavorite]"]);
    const toggleFavorite = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"])({
        "ProductCard.useFavoritesStore[toggleFavorite]": (s)=>s.toggleFavorite
    }["ProductCard.useFavoritesStore[toggleFavorite]"]);
    const desc = product.descricao?.trim() ?? "";
    const imageSrc = product.imagem && !imageError ? product.imagem : FALLBACK_IMAGE;
    const descriptionSnippet = desc.length > 70 ? desc.slice(0, 70).trim() + "..." : desc || "";
    const priceNumber = parseFloat(product.preco);
    const showPrice = !Number.isNaN(priceNumber) && priceNumber > 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2 pt-3 pb-3 px-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-gray-900 font-bold text-[15px] leading-tight min-h-[30px]",
                        children: product.nome
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                        lineNumber: 56,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-900 text-sm",
                        children: product.codigo
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                        lineNumber: 59,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                lineNumber: 55,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                className: "bg-white border relative border-gray-200 shadow-sm rounded-md overflow-hidden flex flex-col text-center pb-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-white pb-10 flex items-center justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-full aspect-square max-h-[170px] overflow-visible min-h-[120px]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: imageSrc,
                                    alt: product.nome,
                                    fill: true,
                                    className: "object-contain",
                                    sizes: "(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw",
                                    priority: isLcpCandidate,
                                    fetchPriority: isLcpCandidate ? "high" : undefined,
                                    loading: isAboveFold && !isLcpCandidate ? "eager" : undefined,
                                    onError: ()=>setImageError(true)
                                }, void 0, false, {
                                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                    lineNumber: 66,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: (e)=>{
                                        e.stopPropagation();
                                        toggleFavorite(product.codigo);
                                    },
                                    "aria-label": isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos",
                                    className: "absolute top-2 left-2 z-20 p-1.5 rounded-full bg-white/90 shadow hover:bg-white focus:outline-none focus:ring-2 focus:ring-[#80bc04] focus:ring-offset-1 focus-visible:ring-2 focus-visible:ring-[#80bc04] focus-visible:ring-offset-1",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                                        className: `size-5 ${isFavorite ? "fill-red-500 text-red-500" : "text-gray-400"}`,
                                        strokeWidth: 2,
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                        lineNumber: 88,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute top-0 right-0 bg-gray-100 text-[#20b3ca] text-xs font-bold px-2 py-[2px] rounded z-20",
                                    children: "EXCLUSIVO!"
                                }, void 0, false, {
                                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                    lineNumber: 96,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute -bottom-10 left-0 w-fit border border-l-0 rounded-t-lg bg-white p-2 flex items-center gap-2 overflow-visible z-20",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute -top-2 bg-white left-1 w-14 h-14 shrink-0",
                                            "aria-hidden": true,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: "/box.png",
                                                alt: "",
                                                fill: true,
                                                className: "object-contain",
                                                sizes: "56px"
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                                lineNumber: 107,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                            lineNumber: 106,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-12 shrink-0"
                                        }, void 0, false, {
                                            fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                            lineNumber: 116,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col gap-1 items-start",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-600 font-bold text-[11px] leading-tight",
                                                    children: "com embalagem"
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 15
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-600 font-bold text-[11px] leading-tight",
                                                    children: "especial"
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                                    lineNumber: 122,
                                                    columnNumber: 15
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                            lineNumber: 118,
                                            columnNumber: 13
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                    lineNumber: 101,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                            lineNumber: 65,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    descriptionSnippet && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 text-xs px-3 pt-2 text-left line-clamp-2 min-h-[42px]",
                        children: descriptionSnippet
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-start gap-1.5 px-3 py-2 flex-wrap",
                        "aria-hidden": true,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-700 font-bold text-xs",
                                children: "Cores:"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                lineNumber: 139,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-4",
                                children: PLACEHOLDER_COLORS.map((color, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-4 h-4 rounded-full border border-gray-200",
                                        style: {
                                            backgroundColor: color
                                        }
                                    }, i, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                        lineNumber: 142,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                lineNumber: 140,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                        lineNumber: 138,
                        columnNumber: 9
                    }, this),
                    showPrice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-3 pb-2 text-right absolute bottom-1 right-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500 text-[11px]",
                                children: "a partir de"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                lineNumber: 154,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-black font-bold text-lg leading-tight",
                                children: formatPrice(product.preco)
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                lineNumber: 155,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-900 text-[10px]",
                                children: "gerado pela melhor oferta"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                                lineNumber: 158,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                        lineNumber: 153,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3 pt-1 mt-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    onClick: (e)=>openModal(product, e.currentTarget),
                    className: "w-full bg-[#80bc04] text-white text-sm font-semibold py-2 rounded hover:bg-[#6fa803] transition focus:outline-none focus:ring-2 focus:ring-[#80bc04] focus:ring-offset-2 focus-visible:ring-2 focus-visible:ring-[#80bc04] focus-visible:ring-offset-2",
                    children: "CONFIRA"
                }, void 0, false, {
                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                    lineNumber: 167,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_s(ProductCard, "iGK0tM8BJhPsxQ58FxaWtn+O16o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$productModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductModalStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"]
    ];
});
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductCardSkeleton",
    ()=>ProductCardSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function ProductCardSkeleton() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center",
        role: "presentation",
        "aria-busy": "true",
        "aria-label": "Carregando produto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-2 pt-3 pb-3 px-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-5 w-3/4 bg-gray-200 rounded animate-pulse mx-auto"
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                        lineNumber: 17,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-4 w-1/3 bg-gray-100 rounded animate-pulse mx-auto"
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                        lineNumber: 18,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                className: "bg-white border relative border-gray-200 shadow-sm rounded-md overflow-hidden flex flex-col text-center pb-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-gray-50 pb-10 flex items-center justify-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-full aspect-square max-h-[170px] bg-gray-200 animate-pulse"
                        }, void 0, false, {
                            fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-3 pt-2 space-y-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-3 w-full bg-gray-100 rounded animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-3 w-2/3 bg-gray-100 rounded animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                                lineNumber: 30,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-start gap-1.5 px-3 py-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-3 w-12 bg-gray-100 rounded animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                                lineNumber: 35,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-4 gap-1",
                                children: [
                                    1,
                                    2,
                                    3,
                                    4,
                                    5,
                                    6,
                                    7,
                                    8
                                ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-4 h-4 rounded-full bg-gray-100 animate-pulse"
                                    }, i, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                                        lineNumber: 38,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-3 pb-2 text-right absolute bottom-1 right-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-3 w-16 bg-gray-100 rounded animate-pulse ml-auto"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-5 w-20 bg-gray-200 rounded animate-pulse mt-1 ml-auto"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                                lineNumber: 49,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-3 pt-1",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full h-10 bg-gray-200 rounded animate-pulse"
                }, void 0, false, {
                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = ProductCardSkeleton;
var _c;
__turbopack_context__.k.register(_c, "ProductCardSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/components/ProductGridSkeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductGridSkeleton",
    ()=>ProductGridSkeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductCardSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/components/ProductCardSkeleton.tsx [app-client] (ecmascript)");
"use client";
;
;
const DEFAULT_COUNT = 8;
function ProductGridSkeleton({ count = DEFAULT_COUNT, "aria-label": ariaLabel = "Carregando produtos" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4",
        role: "status",
        "aria-busy": "true",
        "aria-label": ariaLabel,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "sr-only",
                children: ariaLabel
            }, void 0, false, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductGridSkeleton.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            Array.from({
                length: count
            }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductCardSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCardSkeleton"], {}, i, false, {
                    fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductGridSkeleton.tsx",
                    lineNumber: 30,
                    columnNumber: 9
                }, this))
        ]
    }, void 0, true, {
        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductGridSkeleton.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_c = ProductGridSkeleton;
var _c;
__turbopack_context__.k.register(_c, "ProductGridSkeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductsSection",
    ()=>ProductsSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$hooks$2f$useProducts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/hooks/useProducts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/favoritesStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/components/ProductCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductGridSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/components/ProductGridSkeleton.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ProductsSection() {
    _s();
    const loadMoreRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [showOnlyFavorites, setShowOnlyFavorites] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const hydrate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"])({
        "ProductsSection.useFavoritesStore[hydrate]": (s)=>s.hydrate
    }["ProductsSection.useFavoritesStore[hydrate]"]);
    const favoriteIds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"])({
        "ProductsSection.useFavoritesStore[favoriteIds]": (s)=>s.favoriteIds
    }["ProductsSection.useFavoritesStore[favoriteIds]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsSection.useEffect": ()=>{
            hydrate();
        }
    }["ProductsSection.useEffect"], [
        hydrate
    ]);
    const { products, search, setSearch, sortBy, sortOrder, toggleSort, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading, isError, refetch, isEmpty } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$hooks$2f$useProducts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProducts"])();
    const displayProducts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductsSection.useMemo[displayProducts]": ()=>{
            if (!showOnlyFavorites) return products;
            return products.filter({
                "ProductsSection.useMemo[displayProducts]": (p)=>favoriteIds.includes(p.codigo)
            }["ProductsSection.useMemo[displayProducts]"]);
        }
    }["ProductsSection.useMemo[displayProducts]"], [
        products,
        showOnlyFavorites,
        favoriteIds
    ]);
    const favoritesFilterEmpty = showOnlyFavorites && displayProducts.length === 0 && !isLoading;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductsSection.useEffect": ()=>{
            if (!hasNextPage || isFetchingNextPage) return;
            const el = loadMoreRef.current;
            if (!el) return;
            const obs = new IntersectionObserver({
                "ProductsSection.useEffect": (entries)=>{
                    if (entries[0]?.isIntersecting) fetchNextPage();
                }
            }["ProductsSection.useEffect"], {
                rootMargin: "100px"
            });
            obs.observe(el);
            return ({
                "ProductsSection.useEffect": ()=>obs.disconnect()
            })["ProductsSection.useEffect"];
        }
    }["ProductsSection.useEffect"], [
        hasNextPage,
        isFetchingNextPage,
        fetchNextPage
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "space-y-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "flex items-center gap-2 cursor-pointer",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "checkbox",
                                checked: showOnlyFavorites,
                                onChange: (e)=>setShowOnlyFavorites(e.target.checked),
                                className: "rounded border-gray-300 text-[#80bc04] focus:ring-[#80bc04]"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 64,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm text-gray-700",
                                children: "Mostrar apenas favoritos"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 70,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    showOnlyFavorites && favoriteIds.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs text-gray-500",
                        children: [
                            "(",
                            favoriteIds.length,
                            " favorito",
                            favoriteIds.length !== 1 ? "s" : "",
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 73,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-3 md:flex-row md:items-center md:justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-gray-400",
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 82,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "products-search",
                                className: "sr-only",
                                children: "Buscar por nome ou código"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: "products-search",
                                type: "search",
                                placeholder: "Buscar por nome ou código...",
                                value: search,
                                onChange: (e)=>setSearch(e.target.value),
                                "aria-label": "Buscar por nome ou código do produto",
                                className: "w-full md:w-72 pl-9 pr-3 py-2 border text-gray-900 border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#80bc04] focus:border-transparent focus-visible:ring-2"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 86,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 81,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>toggleSort("nome"),
                                "aria-label": sortBy === "nome" ? `Ordenar por nome ${sortOrder === "asc" ? "A a Z" : "Z a A"}` : "Ordenar por nome",
                                className: `px-3 py-1.5 rounded-lg text-sm font-medium border bg-white hover:bg-gray-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#80bc04] focus-visible:ring-offset-2 ${sortBy === "nome" ? "border-[#80bc04] bg-[#80bc04]/10 text-[#80bc04]" : "border-gray-300 text-gray-700"}`,
                                children: [
                                    "Nome ",
                                    sortBy === "nome" ? sortOrder === "asc" ? "A→Z" : "Z→A" : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>toggleSort("preco"),
                                "aria-label": sortBy === "preco" ? `Ordenar por preço ${sortOrder === "asc" ? "menor primeiro" : "maior primeiro"}` : "Ordenar por preço",
                                className: `px-3 py-1.5 rounded-lg text-sm font-medium border bg-white hover:bg-gray-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#80bc04] focus-visible:ring-offset-2 ${sortBy === "preco" ? "border-[#80bc04] bg-[#80bc04]/10 text-[#80bc04]" : "border-gray-300 text-gray-700"}`,
                                children: [
                                    "Preço ",
                                    sortBy === "preco" ? sortOrder === "asc" ? "↑" : "↓" : ""
                                ]
                            }, void 0, true, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 109,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this),
            isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductGridSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductGridSkeleton"], {
                count: 10,
                "aria-label": "Carregando produtos"
            }, void 0, false, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                lineNumber: 126,
                columnNumber: 9
            }, this) : isError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-12 px-4 bg-gray-50 rounded-xl border border-gray-200",
                role: "alert",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-700 font-medium",
                        children: "Não foi possível carregar os produtos."
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-500 text-sm mt-1 mb-4",
                        children: "Verifique sua conexão e tente novamente."
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 135,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>refetch(),
                        className: "px-4 py-2 rounded-lg bg-[#80bc04] text-white text-sm font-medium hover:bg-[#6fa803] transition focus:outline-none focus:ring-2 focus:ring-[#80bc04] focus:ring-offset-2 focus-visible:ring-2 focus-visible:ring-[#80bc04] focus-visible:ring-offset-2",
                        children: "Tentar novamente"
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 138,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                lineNumber: 128,
                columnNumber: 9
            }, this) : favoritesFilterEmpty ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-12 px-4 bg-gray-50 rounded-xl border border-gray-200",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 font-medium",
                        children: "Você ainda não tem favoritos ou eles foram removidos."
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 148,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-500 text-sm mt-1 mb-4",
                        children: "Desmarque o filtro para ver todos os produtos e adicione favoritos."
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 151,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setShowOnlyFavorites(false),
                        className: "px-4 py-2 rounded-lg bg-[#80bc04] text-white text-sm font-medium hover:bg-[#6fa803] transition focus:outline-none focus:ring-2 focus:ring-[#80bc04] focus:ring-offset-2",
                        children: "Mostrar todos os produtos"
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 154,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                lineNumber: 147,
                columnNumber: 9
            }, this) : isEmpty ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-12 px-4 bg-gray-50 rounded-xl border border-gray-200",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 font-medium",
                        children: "Nenhum produto encontrado."
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 164,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-500 text-sm mt-1",
                        children: "Tente outro termo de busca ou código."
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 165,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                lineNumber: 163,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4",
                        children: displayProducts.map((product, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                                product: product,
                                isAboveFold: index < 8,
                                isLcpCandidate: index === 0
                            }, product.codigo, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                                lineNumber: 173,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 171,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: loadMoreRef,
                        className: "h-4 mt-4",
                        "aria-hidden": true
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 181,
                        columnNumber: 11
                    }, this),
                    isFetchingNextPage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductGridSkeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductGridSkeleton"], {
                            count: 4,
                            "aria-label": "Carregando mais produtos"
                        }, void 0, false, {
                            fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                            lineNumber: 184,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
                        lineNumber: 183,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(ProductsSection, "/GVZ3gr8TIxj/ynggtU0t+mk5Bs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$favoritesStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFavoritesStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$hooks$2f$useProducts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProducts"]
    ];
});
_c = ProductsSection;
var _c;
__turbopack_context__.k.register(_c, "ProductsSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProdutosPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/lucide-react/dist/esm/icons/loader.js [app-client] (ecmascript) <export default as Loader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/lucide-react/dist/esm/icons/mail.js [app-client] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/lucide-react/dist/esm/icons/phone.js [app-client] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/authStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$productModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/productModalStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/components/ProductsSection.tsx [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
const ProductModal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/innovation-brindes-frontend-challenge/components/ProductModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((m)=>({
            default: m.ProductModal
        })), {
    loadableGenerated: {
        modules: [
            "[project]/innovation-brindes-frontend-challenge/components/ProductModal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = ProductModal;
function LazyProductModal() {
    _s();
    const hasEverOpened = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$productModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductModalStore"])({
        "LazyProductModal.useProductModalStore[hasEverOpened]": (s)=>s.hasEverOpened
    }["LazyProductModal.useProductModalStore[hasEverOpened]"]);
    if (!hasEverOpened) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ProductModal, {}, void 0, false, {
        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
        lineNumber: 23,
        columnNumber: 10
    }, this);
}
_s(LazyProductModal, "vORzgQEksEYtE4pUNHCMnadQyCk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$productModalStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useProductModalStore"]
    ];
});
_c1 = LazyProductModal;
function formatDatePT(date) {
    const str = date.toLocaleDateString("pt-BR", {
        weekday: "long",
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
    return str.charAt(0).toUpperCase() + str.slice(1);
}
function ProdutosPage() {
    _s1();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const user = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "ProdutosPage.useAuthStore[user]": (state)=>state.user
    }["ProdutosPage.useAuthStore[user]"]);
    const hasHydrated = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "ProdutosPage.useAuthStore[hasHydrated]": (state)=>state.hasHydrated
    }["ProdutosPage.useAuthStore[hasHydrated]"]);
    const logout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "ProdutosPage.useAuthStore[logout]": (state)=>state.logout
    }["ProdutosPage.useAuthStore[logout]"]);
    function handleLogout() {
        logout();
        router.replace("/login");
    }
    if (!hasHydrated) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen flex flex-col items-center justify-center gap-4 px-4 bg-white text-gray-900",
            "aria-live": "polite",
            "aria-busy": "true",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader$3e$__["Loader"], {
                    className: "animate-spin text-lime-500"
                }, void 0, false, {
                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                    lineNumber: 55,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                lineNumber: 54,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
            lineNumber: 49,
            columnNumber: 7
        }, this);
    }
    if (!user) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen flex flex-col items-center justify-center gap-4 px-4 bg-white text-gray-900",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600",
                    children: "Você precisa estar logado para acessar esta página."
                }, void 0, false, {
                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/login",
                    className: "text-[#80bc04] font-medium hover:underline",
                    children: "Ir para login"
                }, void 0, false, {
                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                    lineNumber: 67,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
            lineNumber: 63,
            columnNumber: 7
        }, this);
    }
    const today = formatDatePT(new Date());
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "bg-[#80bc04] text-white px-3 py-3 md:px-6 md:py-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between gap-2 md:gap-4 w-full max-w-6xl mx-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/produtos",
                            className: "shrink-0",
                            "aria-label": "Innovation Brindes",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: "/logo-innovation-brindes.png",
                                alt: "Innovation Brindes",
                                width: 240,
                                height: 80,
                                className: "h-16 w-auto md:h-16 object-contain object-left",
                                priority: true
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                            lineNumber: 85,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 md:gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-1 md:gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "relative p-1.5 md:p-2 rounded-full hover:bg-white/10 transition",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                    className: "size-5 md:size-6",
                                                    "aria-hidden": true
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                    lineNumber: 105,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-[#9fd356] text-white text-xs font-medium flex items-center justify-center px-1",
                                                    children: "1"
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                    lineNumber: 106,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                            lineNumber: 104,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "relative p-1.5 md:p-2 rounded-full hover:bg-white/10 transition",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                    className: "size-5 md:size-6",
                                                    "aria-hidden": true
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                    lineNumber: 111,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] rounded-full bg-[#9fd356] text-white text-xs font-medium flex items-center justify-center px-1",
                                                    children: "1"
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                            lineNumber: 110,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                    lineNumber: 103,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 md:gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            src: "/clay-elliot.jpg",
                                            alt: "",
                                            width: 50,
                                            height: 50,
                                            className: "size-9 md:size-16 rounded-full object-cover border-6 border-white shrink-0"
                                        }, void 0, false, {
                                            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                            lineNumber: 120,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "hidden min-[420px]:block text-left",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-white/90 font-extralight  text-sm md:text-base leading-tight truncate max-w-[120px] md:max-w-[180px]",
                                                    children: user.nome_usuario.trim()
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                    lineNumber: 128,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-white/90 text-xs md:text-sm leading-tight",
                                                    children: today
                                                }, void 0, false, {
                                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                    lineNumber: 131,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                            lineNumber: 127,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                    lineNumber: 119,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                    lineNumber: 83,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                id: "main-content",
                className: "p-4 md:p-8 max-w-6xl mx-auto",
                tabIndex: -1,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap items-center justify-between gap-4 border-b border-gray-200 pb-4 mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-xl md:text-2xl font-bold text-gray-800",
                                children: "Produtos"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                lineNumber: 146,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: handleLogout,
                                "aria-label": "Sair da conta",
                                className: "cursor-pointer text-sm text-red-600 hover:text-red-700 hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-red-600 focus-visible:ring-offset-2 rounded",
                                children: "Sair"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                lineNumber: 149,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                        lineNumber: 145,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$components$2f$ProductsSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductsSection"], {}, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                        lineNumber: 159,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LazyProductModal, {}, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                        lineNumber: 160,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-10 pt-8 border-t border-gray-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-lg font-semibold text-gray-800 mb-4",
                                children: "Dados do usuário"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                lineNumber: 164,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                                className: "bg-gray-50 rounded-lg border border-gray-200 divide-y divide-gray-200 overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                className: "text-sm font-medium text-gray-500",
                                                children: "Nome"
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 169,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                className: "mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2",
                                                children: user.nome_usuario.trim()
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 170,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                        lineNumber: 168,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                className: "text-sm font-medium text-gray-500",
                                                children: "Código do usuário"
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 175,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                className: "mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2",
                                                children: user.codigo_usuario
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 178,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                        lineNumber: 174,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                className: "text-sm font-medium text-gray-500",
                                                children: "Grupo"
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 183,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                className: "mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2",
                                                children: user.nome_grupo.trim()
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 184,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                        lineNumber: 182,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "px-4 py-3 sm:grid sm:grid-cols-3 sm:gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                                                className: "text-sm font-medium text-gray-500",
                                                children: "Código do grupo"
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 189,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                                                className: "mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2",
                                                children: user.codigo_grupo
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                                lineNumber: 192,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                        lineNumber: 188,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                                lineNumber: 167,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/innovation-brindes-frontend-challenge/app/produtos/page.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, this);
}
_s1(ProdutosPage, "cf5j/GEj0jEfE5xSq4VzUJjRIqI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"]
    ];
});
_c2 = ProdutosPage;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ProductModal");
__turbopack_context__.k.register(_c1, "LazyProductModal");
__turbopack_context__.k.register(_c2, "ProdutosPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=innovation-brindes-frontend-challenge_b7d2621b._.js.map