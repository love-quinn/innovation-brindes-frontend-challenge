(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f62c590a._.css",
  "static/chunks/2a872_497b7012._.js",
  "static/chunks/innovation-brindes-frontend-challenge_0bc0631f._.js"
],
    source: "dynamic"
});
