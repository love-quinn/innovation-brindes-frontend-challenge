(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/innovation-brindes-frontend-challenge_components_ProductModal_tsx_2f5ebcc2._.js",
  "static/chunks/innovation-brindes-frontend-challenge_b7d2621b._.js",
  "static/chunks/2a872_52aea89a._.js"
],
    source: "dynamic"
});
