(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/innovation-brindes-frontend-challenge/services/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "api",
    ()=>api
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/lib/auth-constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/authStore.ts [app-client] (ecmascript)");
;
;
;
const API_BASE_URL = "https://apihomolog.innovationbrindes.com.br/api/innova-dinamica";
const api = __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_BASE_URL,
    headers: {
        "Content-Type": "application/json"
    }
});
/**
 * REQUEST INTERCEPTOR
 * Adiciona automaticamente o token em todas as requisições
 */ api.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]);
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
});
/**
 * RESPONSE INTERCEPTOR
 * 401 → logout (Zustand + localStorage + cookie) e redirect /login
 */ api.interceptors.response.use((response)=>response, (error)=>{
    if (error.response?.status === 401 && ("TURBOPACK compile-time value", "object") !== "undefined") {
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"].getState().logout();
        window.location.href = "/login";
    }
    return Promise.reject(error);
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/services/auth.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loginRequest",
    ()=>loginRequest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/services/api.ts [app-client] (ecmascript)");
;
async function loginRequest(payload) {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["api"].post("/login/acessar", payload);
    return data;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/hooks/useNotification.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useNotification",
    ()=>useNotification
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/react-toastify/dist/index.mjs [app-client] (ecmascript)");
;
const useNotification = ()=>{
    const notifySuccess = (message)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(message, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored"
        });
    };
    const notifyError = (message)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(message, {
            position: "top-right",
            autoClose: 3000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: false,
            draggable: true,
            progress: undefined,
            theme: "colored"
        });
    };
    return {
        notifySuccess,
        notifyError
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/app/login/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LoginPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/react-hook-form/dist/index.esm.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/services/auth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/authStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Lock$3e$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/lucide-react/dist/esm/icons/lock.js [app-client] (ecmascript) <export default as Lock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$hooks$2f$useNotification$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/hooks/useNotification.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function LoginPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const isAuthenticated = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "LoginPage.useAuthStore[isAuthenticated]": (state)=>state.isAuthenticated
    }["LoginPage.useAuthStore[isAuthenticated]"]);
    const loginStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "LoginPage.useAuthStore[loginStore]": (state)=>state.login
    }["LoginPage.useAuthStore[loginStore]"]);
    const { notifySuccess, notifyError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$hooks$2f$useNotification$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotification"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LoginPage.useEffect": ()=>{
            if (isAuthenticated) {
                router.replace("/produtos");
            }
        }
    }["LoginPage.useEffect"], [
        isAuthenticated,
        router
    ]);
    const { register, handleSubmit, formState: { errors }, setError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"])({
        defaultValues: {
            remember: true
        }
    });
    const mutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "LoginPage.useMutation[mutation]": ({ email, senha })=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$services$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loginRequest"])({
                    email,
                    senha
                })
        }["LoginPage.useMutation[mutation]"],
        onSuccess: {
            "LoginPage.useMutation[mutation]": (data, variables)=>{
                if (data.status === 1) {
                    loginStore(data.token_de_acesso, data.dados_usuario, variables.remember);
                    notifySuccess("Login realizado com sucesso!");
                    router.push("/produtos");
                } else {
                    const message = "Usuário ou senha inválidos. Tente novamente.";
                    notifyError(message);
                    setError("root", {
                        message
                    });
                }
            }
        }["LoginPage.useMutation[mutation]"],
        onError: {
            "LoginPage.useMutation[mutation]": ()=>{
                const message = "Não foi possível conectar. Verifique sua internet e tente novamente.";
                notifyError(message);
                setError("root", {
                    message
                });
            }
        }["LoginPage.useMutation[mutation]"]
    });
    function onSubmit(data) {
        mutation.mutate({
            email: data.email,
            senha: data.senha,
            remember: true
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative min-h-screen flex items-center justify-center px-4 py-6 md:py-4 bg-cover bg-center bg-no-repeat",
        style: {
            backgroundImage: "url(/man-in-office.jpg)"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-white/10",
                "aria-hidden": true
            }, void 0, false, {
                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-10 flex flex-col gap-6 md:gap-8 items-center justify-center w-full max-w-[100vw] overflow-x-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-xl md:text-3xl font-bold text-center text-[#80bc04] px-2",
                        children: "Bem-vindo a Innovation Brindes"
                    }, void 0, false, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                        lineNumber: 79,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: handleSubmit(onSubmit),
                        className: "relative z-10 bg-[#80bc04] p-6 md:p-10 rounded-xl shadow-md w-full max-w-[75vw] md:w-full md:max-w-[500px] flex flex-col items-center gap-4 md:gap-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full max-w-[280px] md:max-w-none md:w-[75%] relative",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                        className: "absolute left-3 md:left-6 top-1/2 -translate-y-1/2 size-5 text-gray-500 pointer-events-none z-10",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 89,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "login-email",
                                        className: "sr-only",
                                        children: "Usuário"
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 93,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "login-email",
                                        type: "text",
                                        placeholder: "Usuário",
                                        autoComplete: "username",
                                        className: "w-full bg-white text-[#5d5d5d] rounded-4xl pl-10 md:pl-14 pr-3 py-2.5 md:py-3 text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-blue-500 focus-visible:ring-2 focus-visible:ring-blue-500",
                                        ...register("email", {
                                            required: "O usuário é obrigatório"
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 96,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                lineNumber: 88,
                                columnNumber: 11
                            }, this),
                            errors.email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-red-500 text-sm",
                                role: "alert",
                                children: errors.email.message
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-full max-w-[280px] md:max-w-none md:w-[75%] relative",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$lock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Lock$3e$__["Lock"], {
                                        className: "absolute left-3 md:left-6 top-1/2 -translate-y-1/2 size-5 text-gray-500 pointer-events-none z-10",
                                        "aria-hidden": true
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 115,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "login-senha",
                                        className: "sr-only",
                                        children: "Senha"
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 119,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "login-senha",
                                        type: "password",
                                        placeholder: "Senha",
                                        autoComplete: "current-password",
                                        className: "w-full bg-white text-[#5d5d5d] rounded-4xl pl-10 md:pl-14 pr-3 py-2.5 md:py-3 text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-blue-500 focus-visible:ring-2 focus-visible:ring-blue-500",
                                        ...register("senha", {
                                            required: "A senha é obrigatória"
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 122,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                lineNumber: 114,
                                columnNumber: 11
                            }, this),
                            errors.senha && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-red-500 text-sm",
                                role: "alert",
                                children: errors.senha.message
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                lineNumber: 134,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-2 w-full max-w-[280px] md:max-w-none md:w-[70%]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center gap-2 text-xs md:text-sm text-white",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                ...register("remember"),
                                                defaultChecked: true,
                                                disabled: true,
                                                "aria-label": "Manter logado (sempre ativo)",
                                                className: "cursor-default appearance-none w-4 h-4 border rounded border-white bg-[#80bc04] relative after:content-['✔'] after:absolute after:text-white after:opacity-100 after:inset-0 after:flex after:items-center after:justify-center"
                                            }, void 0, false, {
                                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                                lineNumber: 142,
                                                columnNumber: 15
                                            }, this),
                                            "Manter logado"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 141,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "#",
                                        className: "text-xs md:text-sm text-white hover:underline whitespace-nowrap",
                                        children: "Esqueceu a senha?"
                                    }, void 0, false, {
                                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                        lineNumber: 162,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                lineNumber: 140,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "aria-live": "polite",
                                "aria-atomic": "true",
                                className: "min-h-5",
                                children: errors.root && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-red-500 text-sm",
                                    role: "alert",
                                    children: errors.root.message
                                }, void 0, false, {
                                    fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                    lineNumber: 173,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                lineNumber: 171,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: mutation.isPending,
                                className: "w-full cursor-pointer md:w-[50%] bg-white text-gray-600 py-2.5 md:py-2 rounded-md hover:bg-gray-200 transition text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-[#80bc04] focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#80bc04]",
                                children: mutation.isPending ? "Entrando..." : "Login"
                            }, void 0, false, {
                                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                                lineNumber: 180,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                        lineNumber: 83,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/innovation-brindes-frontend-challenge/app/login/page.tsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
}
_s(LoginPage, "4mYEwGuUqVfSOqRH/VVnUO1p2cM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$hooks$2f$useNotification$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNotification"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$react$2d$hook$2d$form$2f$dist$2f$index$2e$esm$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useForm"],
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
_c = LoginPage;
var _c;
__turbopack_context__.k.register(_c, "LoginPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=innovation-brindes-frontend-challenge_44713bb5._.js.map