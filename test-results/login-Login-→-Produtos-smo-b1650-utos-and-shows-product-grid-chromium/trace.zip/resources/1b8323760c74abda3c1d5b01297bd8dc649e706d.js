(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/innovation-brindes-frontend-challenge/lib/auth-constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Constantes de autenticação compartilhadas entre middleware e auth store.
 * Usado para alinhar a verificação de rota protegida (cookie) com o estado do cliente.
 */ __turbopack_context__.s([
    "AUTH_TOKEN_KEY",
    ()=>AUTH_TOKEN_KEY,
    "AUTH_USER_KEY",
    ()=>AUTH_USER_KEY
]);
const AUTH_TOKEN_KEY = "token";
const AUTH_USER_KEY = "user";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/store/authStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuthStore",
    ()=>useAuthStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/lib/auth-constants.ts [app-client] (ecmascript)");
;
;
const COOKIE_PATH = "/";
const COOKIE_MAX_AGE_REMEMBER = 60 * 60 * 24 * 7 // 7 dias
;
function setTokenCookie(token, remember) {
    if (typeof document === "undefined") return;
    const maxAge = remember ? COOKIE_MAX_AGE_REMEMBER : undefined;
    const opts = `path=${COOKIE_PATH}; SameSite=Lax${maxAge != null ? `; max-age=${maxAge}` : ""}`;
    document.cookie = `${__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]}=${encodeURIComponent(token)}; ${opts}`;
}
function clearTokenCookie() {
    if (typeof document === "undefined") return;
    document.cookie = `${__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]}=; path=${COOKIE_PATH}; max-age=0`;
}
const useAuthStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set)=>({
        token: null,
        user: null,
        isAuthenticated: false,
        rememberMe: false,
        hasHydrated: false,
        login: (token, user, remember)=>{
            if (remember) {
                localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"], token);
                localStorage.setItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_USER_KEY"], JSON.stringify(user));
            }
            setTokenCookie(token, remember);
            set({
                token,
                user,
                isAuthenticated: true,
                rememberMe: remember
            });
        },
        logout: ()=>{
            localStorage.removeItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]);
            localStorage.removeItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_USER_KEY"]);
            clearTokenCookie();
            set({
                token: null,
                user: null,
                isAuthenticated: false,
                rememberMe: false
            });
        },
        loadFromStorage: ()=>{
            const token = localStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]);
            const user = localStorage.getItem(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$lib$2f$auth$2d$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_USER_KEY"]);
            if (token && user) {
                setTokenCookie(token, true);
                set({
                    token,
                    user: JSON.parse(user),
                    isAuthenticated: true,
                    rememberMe: true,
                    hasHydrated: true
                });
            } else {
                set({
                    hasHydrated: true
                });
            }
        }
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/components/AuthInitializer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AuthInitializer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/store/authStore.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AuthInitializer() {
    _s();
    const loadFromStorage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"])({
        "AuthInitializer.useAuthStore[loadFromStorage]": (state)=>state.loadFromStorage
    }["AuthInitializer.useAuthStore[loadFromStorage]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthInitializer.useEffect": ()=>{
            loadFromStorage();
        }
    }["AuthInitializer.useEffect"], [
        loadFromStorage
    ]);
    return null;
}
_s(AuthInitializer, "KLm7OmU6Z/EIy+Rj/5eUaZ9OYgE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$store$2f$authStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthStore"]
    ];
});
_c = AuthInitializer;
var _c;
__turbopack_context__.k.register(_c, "AuthInitializer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/providers/ReactQueryProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReactQueryProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ReactQueryProvider({ children }) {
    _s();
    // useState para evitar recriação do client a cada render
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "ReactQueryProvider.useState": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
                defaultOptions: {
                    queries: {
                        retry: 1,
                        refetchOnWindowFocus: false,
                        staleTime: 60 * 1000
                    }
                }
            })
    }["ReactQueryProvider.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: queryClient,
        children: children
    }, void 0, false, {
        fileName: "[project]/innovation-brindes-frontend-challenge/providers/ReactQueryProvider.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(ReactQueryProvider, "XhQ97je/4zmYRHqLTbjfIQrPC1A=");
_c = ReactQueryProvider;
var _c;
__turbopack_context__.k.register(_c, "ReactQueryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/innovation-brindes-frontend-challenge/components/SkipToContent.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SkipToContent",
    ()=>SkipToContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/innovation-brindes-frontend-challenge/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function SkipToContent() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$innovation$2d$brindes$2d$frontend$2d$challenge$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        href: "#main-content",
        className: "absolute left-[-9999px] top-4 z-[100] px-4 py-2 bg-[#80bc04] text-white rounded-md font-medium focus:left-4 focus:top-4 focus:z-[100] focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-gray-900",
        children: "Pular para o conteúdo principal"
    }, void 0, false, {
        fileName: "[project]/innovation-brindes-frontend-challenge/components/SkipToContent.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = SkipToContent;
var _c;
__turbopack_context__.k.register(_c, "SkipToContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=innovation-brindes-frontend-challenge_0bc0631f._.js.map