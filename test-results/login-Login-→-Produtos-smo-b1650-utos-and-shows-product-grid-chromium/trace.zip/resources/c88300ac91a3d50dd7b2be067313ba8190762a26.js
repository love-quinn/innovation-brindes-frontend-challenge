(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/innovation-brindes-frontend-challenge/components/ProductModal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/2a872_311787da._.js",
  "static/chunks/innovation-brindes-frontend-challenge_components_ProductModal_tsx_744056d5._.js",
  "static/chunks/innovation-brindes-frontend-challenge_components_ProductModal_tsx_da8a6e48._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/innovation-brindes-frontend-challenge/components/ProductModal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);