(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f2852cbc._.js",
  "static/chunks/2a872_next_dist_compiled_react-dom_ed640000._.js",
  "static/chunks/2a872_next_dist_compiled_react-server-dom-turbopack_1b62197e._.js",
  "static/chunks/2a872_next_dist_compiled_next-devtools_index_402eec30.js",
  "static/chunks/2a872_next_dist_compiled_3742ed46._.js",
  "static/chunks/2a872_next_dist_client_9d3dec91._.js",
  "static/chunks/2a872_next_dist_3064d395._.js",
  "static/chunks/2a872_@swc_helpers_cjs_ee95fd0b._.js"
],
    source: "entry"
});
